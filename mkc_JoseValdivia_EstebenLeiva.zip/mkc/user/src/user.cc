#define NORETURN __attribute__((noreturn))
#define EXTERN_C extern "C"

enum
{
    SYS_DUMP        = 0,
    SYS_CREATE_EC   = 1,
    SYS_YIELD       = 2,
    SYS_BLOCK       = 3,
    SYS_UNBLOCK_ALL = 4
};

unsigned syscall1 (unsigned w0)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : : "ecx", "edx");
    return w0;
}

unsigned syscall2 (unsigned w0, unsigned w1)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : "S" (w1) : "ecx", "edx");
    return w0;
}

unsigned syscall3 (unsigned w0, unsigned w1, unsigned w2)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : "S" (w1), "D" (w2) : "ecx", "edx");
    return w0;
}

unsigned syscall4 (unsigned w0, unsigned w1, unsigned w2, unsigned w3)
{
    asm volatile (
        "   mov %%esp, %%ecx    ;"
        "   mov $1f, %%edx      ;"
        "   sysenter            ;"
        "1:                     ;"
        : "+a" (w0) : "S" (w1), "D" (w2), "b" (w3) : "ecx", "edx");
    return w0;
}

unsigned sys_dump (unsigned value)
{
    return syscall2 (SYS_DUMP, value);
}

unsigned sys_create_ec (void (*entry)(), unsigned stack_top, unsigned priority)
{
    return syscall4 (SYS_CREATE_EC,
                     reinterpret_cast<unsigned>(entry),
                     stack_top,
                     priority);
}

unsigned sys_yield()
{
    return syscall1 (SYS_YIELD);
}

unsigned sys_block()
{
    return syscall1 (SYS_BLOCK);
}

unsigned sys_unblock_all()
{
    return syscall1 (SYS_UNBLOCK_ALL);
}

static unsigned char stack_l1[4096] __attribute__((aligned(16)));
static unsigned char stack_l2[4096] __attribute__((aligned(16)));
static unsigned char stack_h1[4096] __attribute__((aligned(16)));
static unsigned char stack_h2[4096] __attribute__((aligned(16)));

void low_1()
{
    for (;;) {
        sys_dump (0x1001);
        sys_yield();
    }
}

void low_2()
{
    for (;;) {
        sys_dump (0x1002);
        sys_yield();
    }
}

void high_1()
{
    for (;;) {
        sys_dump (0x2001);
        sys_yield();

        sys_dump (0x2002);
        sys_block();

        sys_dump (0x2003);
        sys_yield();
    }
}

void high_2()
{
    for (;;) {
        sys_dump (0x2101);
        sys_yield();

        sys_dump (0x2102);
        sys_block();

        sys_dump (0x2103);
        sys_yield();
    }
}

EXTERN_C NORETURN
void main_func()
{
    sys_dump (0x3000);

    sys_create_ec (low_1,
                   reinterpret_cast<unsigned>(stack_l1 + sizeof(stack_l1)),
                   0);

    sys_create_ec (low_2,
                   reinterpret_cast<unsigned>(stack_l2 + sizeof(stack_l2)),
                   0);

    sys_create_ec (high_1,
                   reinterpret_cast<unsigned>(stack_h1 + sizeof(stack_h1)),
                   2);

    sys_create_ec (high_2,
                   reinterpret_cast<unsigned>(stack_h2 + sizeof(stack_h2)),
                   2);

    for (;;) {
        sys_dump (0x3001);
        sys_yield();

        sys_dump (0x3002);
        sys_unblock_all();

        sys_yield();
    }
}
