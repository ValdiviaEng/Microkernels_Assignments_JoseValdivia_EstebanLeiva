/*
 * Execution Context
 *
 * Copyright (C) 2009-2011 Udo Steinberg <udo@hypervisor.org>
 * Economic rights: Technische Universitaet Dresden (Germany)
 *
 * This file is part of the NOVA microhypervisor.
 *
 * NOVA is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * NOVA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License version 2 for more details.
 */

#include "bits.h"
#include "ec.h"
#include "assert.h"
#include "cpu.h"
#include "ptab.h"
#include "multiboot.h"
#include "elf.h"

enum
{
    SYS_DUMP        = 0,
    SYS_CREATE_EC   = 1,
    SYS_YIELD       = 2,
    SYS_BLOCK       = 3,
    SYS_UNBLOCK_ALL = 4
};

Ec * Ec::current = 0;

Ec * Ec::ready_head[Ec::NUM_PRIO] = { 0, 0, 0 };
Ec * Ec::ready_tail[Ec::NUM_PRIO] = { 0, 0, 0 };

Ec * Ec::blocked_head = 0;
Ec * Ec::blocked_tail = 0;

unsigned Ec::next_id = 1;

// solely used for root_invoke()
Ec::Ec (void (*f)(), mword mbi) : cont (f)
{
    id           = next_id++;
    priority     = 0;
    state        = RUNNING;
    next_ready   = 0;
    next_blocked = 0;

    regs.eax = mbi;
    regs.cs  = SEL_USER_CODE;
    regs.ds  = SEL_USER_DATA;
    regs.es  = SEL_USER_DATA;
    regs.ss  = SEL_USER_DATA;
    regs.efl = 0x200;           // IF = 1

    printf ("[ec-init] root ec=%u prio=%u\n", id, priority);
}

// only used by syscall create thread (EC+SC)
Ec::Ec (mword eip, mword esp)
{
    id           = next_id++;
    priority     = 0;
    state        = READY;
    next_ready   = 0;
    next_blocked = 0;

    cont = ret_user_iret;
    regs.cs  = SEL_USER_CODE;
    regs.ds  = SEL_USER_DATA;
    regs.es  = SEL_USER_DATA;
    regs.ss  = SEL_USER_DATA;
    regs.efl = 0x200;           // IF = 1
    regs.eip = eip;
    regs.esp = esp;

    printf ("[ec-init] user ec=%u eip=%#lx esp=%#lx\n", id, eip, esp);
}

unsigned Ec::normalize_prio (unsigned p)
{
    if (p >= NUM_PRIO)
        return NUM_PRIO - 1;

    return p;
}

void Ec::enqueue_ready (Ec *ec)
{
    if (!ec)
        return;

    unsigned p = normalize_prio (ec->priority);

    ec->priority = p;
    ec->state = READY;
    ec->next_ready = 0;

    if (!ready_head[p]) {

        ready_head[p] = ec;
        ready_tail[p] = ec;

    } else {

        ready_tail[p]->next_ready = ec;
        ready_tail[p] = ec;
    }

    printf ("[ready+] ec=%u prio=%u\n", ec->id, ec->priority);
}

Ec * Ec::dequeue_ready()
{
    for (int p = static_cast<int>(NUM_PRIO) - 1; p >= 0; --p) {

        Ec *ec = ready_head[p];

        if (!ec)
            continue;

        ready_head[p] = ec->next_ready;

        if (!ready_head[p])
            ready_tail[p] = 0;

        ec->next_ready = 0;

        printf ("[ready-] ec=%u prio=%d\n", ec->id, p);

        return ec;
    }

    return 0;
}

void Ec::enqueue_blocked (Ec *ec)
{
    if (!ec)
        return;

    ec->state = BLOCKED;
    ec->next_blocked = 0;

    if (!blocked_head) {

        blocked_head = ec;
        blocked_tail = ec;

    } else {

        blocked_tail->next_blocked = ec;
        blocked_tail = ec;
    }

    printf ("[block+] ec=%u prio=%u\n", ec->id, ec->priority);
}

void Ec::yield_current()
{
    Ec *old = current;
    Ec *next = dequeue_ready();

    if (!next) {
        printf ("[yield] ec=%u no other ready ec\n", old->id);
        return;
    }

    old->cont = ret_user_sysexit;
    enqueue_ready (old);

    next->state = RUNNING;
    current = next;

    printf ("[yield] from=%u to=%u\n", old->id, next->id);

    next->make_current();

    UNREACHED;
}

void Ec::block_current()
{
    Ec *old = current;

    printf ("[block] ec=%u prio=%u\n", old->id, old->priority);

    old->cont = ret_user_sysexit;
    enqueue_blocked (old);

    Ec *next = dequeue_ready();

    if (!next)
        panic ("[block] no ready EC after blocking current\n");

    next->state = RUNNING;
    current = next;

    printf ("[switch] from=%u blocked to=%u\n", old->id, next->id);

    next->make_current();

    UNREACHED;
}

void Ec::unblock_all()
{
    printf ("[unblock_all] start\n");

    Ec *ec = blocked_head;

    blocked_head = 0;
    blocked_tail = 0;

    while (ec) {

        Ec *next = ec->next_blocked;

        ec->next_blocked = 0;
        ec->state = READY;

        printf ("[unblock] ec=%u prio=%u\n", ec->id, ec->priority);

        enqueue_ready (ec);

        ec = next;
    }

    printf ("[unblock_all] done\n");
}

void Ec::ret_user_sysexit()
{
    asm volatile ("lea %0, %%esp;"
                  "popa;"
                  "sti;"
                  "sysexit"
                  : : "m" (current->regs) : "memory");

    UNREACHED;
}

void Ec::ret_user_iret()
{
    asm volatile ("lea %0, %%esp;"
                  "popa;"
                  "pop %%gs;"
                  "pop %%fs;"
                  "pop %%es;"
                  "pop %%ds;"
                  "add $8, %%esp;"
                  "iret"
                  : : "m" (current->regs) : "memory");

    UNREACHED;
}

void Ec::root_invoke()
{
    // find multi boot info
    Multiboot * mbi = static_cast<Multiboot *>(Ptab::remap (current->regs.eax));

    if (!(mbi->flags & 8) || (mbi->mods_count != 1))
        panic ("exactly ONE multi boot module is required.\n");

    // load module descriptor
    Multiboot_module mod = *static_cast<Multiboot_module *>(Ptab::remap (mbi->mods_addr));

    printf ("load module from %x - %x (%u bytes) : ", mod.mod_start, mod.mod_end, mod.mod_end - mod.mod_start);
    char * cmd = static_cast<char *>(Ptab::remap (mod.cmdline));
    printf ("%s\n",cmd);

    // remap elf header
    Eh * e = static_cast<Eh *>(Ptab::remap (mod.mod_start));
    if (e->ei_magic != 0x464c457f || e->ei_data != 1 || e->type != 2)
        panic ("No ELF\n");

    unsigned count = e->ph_count;
    current->regs.eip = e->entry;

    // remap program headers
    Ph * p = static_cast<Ph *>(Ptab::remap (mod.mod_start + e->ph_offset));

    for (; count--; p++) {

        if (p->type == Ph::PT_LOAD) {

            unsigned attr = p->flags & Ph::PF_W ? 7 : 5;

            if (p->f_size != p->m_size || p->v_addr % PAGE_SIZE != p->f_offs % PAGE_SIZE)
                panic ("Bad ELF\n");

            mword phys = align_dn (p->f_offs + mod.mod_start, PAGE_SIZE);
            mword virt = align_dn (p->v_addr, PAGE_SIZE);
            mword size = align_up (p->f_size, PAGE_SIZE);

            while (size) {
                Ptab::insert_mapping (virt, phys, attr);
                virt += PAGE_SIZE;
                phys += PAGE_SIZE;
                size -= PAGE_SIZE;
            }
        }
    }

    ret_user_iret();

    FAIL;
}

void Ec::handle_tss()
{
    panic ("Task gate invoked\n");
}

void Ec::syscall_handler (uint8 n)
{
    current->cont = ret_user_sysexit;

    switch (n) {

    case SYS_DUMP:
        sys_dump();
        break;

    case SYS_CREATE_EC:
    {
        mword entry = current->sys_regs()->esi;
        mword stack = current->sys_regs()->edi;
        unsigned prio = normalize_prio (current->sys_regs()->ebx);

        Ec *child = new Ec (entry, stack);

        child->priority = prio;
        child->state = READY;
        child->next_ready = 0;
        child->next_blocked = 0;

        enqueue_ready (child);

        current->sys_regs()->eax = child->id;

        printf ("[create] ec=%u prio=%u entry=%#lx stack=%#lx\n",
                child->id, child->priority, entry, stack);

        break;
    }

    case SYS_YIELD:
        yield_current();
        break;

    case SYS_BLOCK:
        block_current();
        break;

    case SYS_UNBLOCK_ALL:
        unblock_all();
        current->sys_regs()->eax = 0;
        break;

    default:
        printf ("syscall %d - unknown\n", n);
        break;
    }

    ret_user_sysexit();

    UNREACHED;
}

void Ec::sys_dump()
{
    printf ("EC:%p SYS_DUMP : %#lx, %#lx\n", current, current->sys_regs()->esi, current->sys_regs()->edi);

    ret_user_sysexit();
}

bool Ec::handle_exc_ts (Exc_regs *r)
{
    if (r->user())
        return false;

    // SYSENTER with EFLAGS.NT=1 and IRET faulted
    r->efl &= ~0x4000; // nested task eflag

    return true;
}

void Ec::handle_exc (Exc_regs *r)
{
    if (r->vec == Cpu::EXC_TS && handle_exc_ts (r))
        return;

    if (r->vec == Cpu::EXC_GP)
        panic ("%s GP (EIP=%#lx CR2=%#lx)\n", r->eip < LINK_ADDR ? "User" : "Kernel", r->eip, r->cr2);

    if (r->vec == Cpu::EXC_PF)
        panic ("%s PF (EIP=%#lx CR2=%#lx)\n", r->eip < LINK_ADDR ? "User" : "Kernel", r->eip, r->cr2);

    panic ("%s EXC %#lx (EIP=%#lx CR2=%#lx)\n", r->eip < LINK_ADDR ? "User" : "Kernel", r->vec, r->eip, r->cr2);

    UNREACHED;
}
